

# Plantquest Python Room

class Room:
    def __init__(self, sdk, definition):
        self.sdk = sdk
        self.definition = definition

    def save(self, data):
        self.data = data

        # TODO: validate data
        body = sdk.body('save', self.data)

        method = sdk.method(self)

        spec = {
          'url': sdk.endpoint(self),
          'method': method,
          'headers': {
            'content-type': 'application/json'
          },
          'body': body
        }
        res = self.sdk.options.fetch(spec)
        statusCode = res.status_code

        if(200 == statusCode):
            # json
            self.data = {}
            '''
            TODO:
            const json = await res.json()
            self.data = json.ent

            '''
        else:
            # TODO: More specific Exception class
            raise Exception('HTTP-ERROR: save: room: ' + str(statusCode))

        return self

    def load(self, data):
        self.data = data
        # TODO: check if data.id is defined

        body = self.sdk.body('load', self.data)
        method = self.sdk.body('load', self)

        url = self.sdk.endpoint('load', self)
  
        # TODO: More options for auth
        spec = {
          'method': method,
          'headers': {
            'content-type': 'application/json',
            'authorization': 'Bearer ' +  self.sdk.options.apikey
          }
        }
        
        res = self.sdk.options.fetch(url, spec)
        statusCode = res.status_code

        if(200 == statusCode):
            # json
            self.data = {}
            '''
            TODO:
            const json = await res.json()
            self.data = json.ent

            '''
        else:
            # TODO: More specific Exception class
            raise Exception('HTTP-ERROR: load: room: ' + str(statusCode))

        return self

