
# Plantquest Python SDK

## Install

```

pip install pythonSDK

```


## Options


* __apikey (String)__: PlantQuest API Key

* __endpoint (String)__: PlantQuest API URL


## Entities

### Entity: __Asset__

_undefined_



### Entity: __Geofence__

_undefined_



### Entity: __Room__

_undefined_


